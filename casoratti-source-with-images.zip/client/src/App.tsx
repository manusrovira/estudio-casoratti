import { Route, Switch } from "wouter";
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import SiteShell from "./components/SiteShell";
import { Areas, AreaDetail, Contact, FAQ, Home, Resources, Studio, Values } from "./pages/SitePages";
import NotFound from "./pages/NotFound";

function Router() {
  return <Switch>
    <Route path="/" component={Home} />
    <Route path="/el-estudio" component={Studio} />
    <Route path="/areas" component={Areas} />
    <Route path="/areas/:slug" component={AreaDetail} />
    <Route path="/valores" component={Values} />
    <Route path="/recursos" component={Resources} />
    <Route path="/preguntas-frecuentes" component={FAQ} />
    <Route path="/contacto" component={Contact} />
    <Route path="/404" component={NotFound} />
    <Route component={NotFound} />
  </Switch>;
}

export default function App() {
  return <ErrorBoundary><ThemeProvider defaultTheme="light"><TooltipProvider><Toaster /><SiteShell><Router /></SiteShell></TooltipProvider></ThemeProvider></ErrorBoundary>;
}
